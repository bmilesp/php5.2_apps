/************************************************************************
Some type definitions

(c) 1994-2000 Innobase Oy

Created 9/21/2000 Heikki Tuuri
*************************************************************************/

#ifndef data0types_h
#define data0types_h

/* SQL data field struct */
typedef struct dfield_struct	dfield_t;

/* SQL data tuple struct */
typedef struct dtuple_struct	dtuple_t;

#endif

